import json
import os
import pika
from fastapi import FastAPI, Body
from pydantic import BaseModel

RABBITMQ_URL = os.getenv("RABBITMQ_URL", "amqp://guest:guest@localhost:5672/")
QUEUE_NAME = os.getenv("QUEUE_NAME", "mensagens")

# Setup connection/channel once (simple demo; in prod, handle reconnects and heartbeat)
params = pika.URLParameters(RABBITMQ_URL)
connection = pika.BlockingConnection(params)
channel = connection.channel()
channel.queue_declare(queue=QUEUE_NAME, durable=True)

class Mensagem(BaseModel):
    nome: str
    texto: str

app = FastAPI(title="FastAPI + RabbitMQ (mensageria simples)")

@app.post("/enviar")
def enviar(mensagem: Mensagem = Body(...)):
    payload = mensagem.model_dump()
    channel.basic_publish(
        exchange="",
        routing_key=QUEUE_NAME,
        body=json.dumps(payload).encode("utf-8"),
        properties=pika.BasicProperties(delivery_mode=2)  # persistente
    )
    return {"status": "ok", "enviado_para": QUEUE_NAME, "payload": payload}

@app.get("/health")
def health():
    return {"status": "ok"}
